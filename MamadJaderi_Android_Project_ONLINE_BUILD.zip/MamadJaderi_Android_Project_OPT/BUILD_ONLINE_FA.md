# ساخت APK آنلاین برای ممدجادری

این پروژه برای Build آنلاین آماده شده است.

## مشخصات Build
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- compileSdk: 35
- خروجی: `app-debug.apk`

## ساخت با GitHub Actions
1. پروژه را داخل یک Repository در GitHub قرار دهید.
2. به بخش **Actions** بروید.
3. Workflow با نام **Build MamadJaderi APK** را انتخاب کنید.
4. گزینه **Run workflow** را بزنید.
5. بعد از اتمام موفق Build، در صفحه اجرای Workflow قسمت **Artifacts** فایل `MamadJaderi-debug-apk` را دانلود کنید.

Workflow به‌صورت خودکار JDK 17، Gradle 8.9 و Android SDK 35 را روی Runner تنظیم می‌کند و APK را می‌سازد.
