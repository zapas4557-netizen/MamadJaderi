package com.hossein.mamadjaderi;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler handler = new Handler();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        hideSystemBars();
        showSplash();
    }

    private void hideSystemBars() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().getInsetsController().hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            getWindow().getInsetsController().setSystemBarsBehavior(WindowInsetsControllerBehavior());
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    private int WindowInsetsControllerBehavior() {
        return android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE;
    }

    private void showSplash() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5,8,15));

        ImageView image = new ImageView(this);
        image.setImageResource(com.hossein.mamadjaderi.R.drawable.splash_hossein);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(image, new FrameLayout.LayoutParams(-1, -1));

        View shade = new View(this);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0x33000000,0x99000000,0xDD05080F});
        shade.setBackground(gd);
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setGravity(Gravity.CENTER);
        text.setPadding(40,20,40,30);

        TextView designer = new TextView(this);
        designer.setText("طراح حسین");
        designer.setTextColor(Color.WHITE);
        designer.setTextSize(34);
        designer.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        designer.setGravity(Gravity.CENTER);
        designer.setShadowLayer(18,0,5,Color.BLACK);

        TextView present = new TextView(this);
        present.setText("تقدیم به ممد جادری");
        present.setTextColor(Color.rgb(255,215,75));
        present.setTextSize(25);
        present.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        present.setGravity(Gravity.CENTER);
        present.setShadowLayer(16,0,4,Color.BLACK);

        text.addView(designer, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 12;
        text.addView(present, p);
        root.addView(text, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);

        handler.postDelayed(this::loadGame, 2400);
    }

    private void loadGame() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        hideSystemBars();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private String jsKey(String key) {
        return "javascript:(function(){window.dispatchEvent(new KeyboardEvent('keydown',{key:'" + key + "',bubbles:true}));})()";
    }
    private String jsKeyUp(String key) {
        return "javascript:(function(){window.dispatchEvent(new KeyboardEvent('keyup',{key:'" + key + "',bubbles:true}));})()";
    }

    private String mapKey(int code) {
        switch(code) {
            case KeyEvent.KEYCODE_DPAD_LEFT: return "ArrowLeft";
            case KeyEvent.KEYCODE_DPAD_RIGHT: return "ArrowRight";
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_BUTTON_A:
            case KeyEvent.KEYCODE_BUTTON_X:
            case KeyEvent.KEYCODE_BUTTON_Y: return "ArrowUp";
            case KeyEvent.KEYCODE_BUTTON_START: return "Escape";
            default: return null;
        }
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        String key = mapKey(event.getKeyCode());
        if (key != null && webView != null) {
            if (event.getAction() == KeyEvent.ACTION_DOWN && !event.isRepeat()) webView.evaluateJavascript(jsKey(key), null);
            if (event.getAction() == KeyEvent.ACTION_UP) webView.evaluateJavascript(jsKeyUp(key), null);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override protected void onResume() { super.onResume(); hideSystemBars(); if (webView != null) webView.onResume(); }
    @Override protected void onPause() { if (webView != null) webView.onPause(); super.onPause(); }
    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("javascript:(function(){if(window.state==='playing'){togglePause()}else{document.getElementById('backBtn')?.click()}})()", null);
        else super.onBackPressed();
    }
}
